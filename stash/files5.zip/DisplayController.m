#import "DisplayController.h"

extern CGError CGSConfigureDisplayEnabled(CGDisplayConfigRef, CGDirectDisplayID, bool);

static void displayReconfigCallback(CGDirectDisplayID displayID,
                                    CGDisplayChangeSummaryFlags flags,
                                    void *userInfo) {
    DisplayController *controller = (__bridge DisplayController *)userInfo;
    [controller handleReconfiguration:displayID flags:flags];
}

@implementation DisplayController {
    CGDirectDisplayID _builtInID;
    BOOL _isBlackedOut;
    BOOL _applyingChange;
}

- (instancetype)init {
    if (!(self = [super init])) return nil;
    _builtInID = [self discoverBuiltInID];
    _autoBlackoutOnExternalConnect = YES;
    CGDisplayRegisterReconfigurationCallback(displayReconfigCallback,
                                             (__bridge void *)self);
    return self;
}

- (void)dealloc {
    CGDisplayRemoveReconfigurationCallback(displayReconfigCallback,
                                           (__bridge void *)self);
}

- (BOOL)isBlackedOut { return _isBlackedOut; }

// MARK: - Public

- (BOOL)enableBlackout {
    if (_isBlackedOut) return YES;
    if (![self hasActiveExternalDisplay]) {
        NSLog(@"blackoutd: refusing blackout — no active external display");
        return NO;
    }
    CGError err = [self setDisplay:_builtInID enabled:NO];
    if (err != kCGErrorSuccess) {
        NSLog(@"blackoutd: disable failed: %d", err);
        return NO;
    }
    _isBlackedOut = YES;
    [_delegate displayController:self blackoutStateChanged:YES];
    return YES;
}

- (BOOL)disableBlackout {
    if (!_isBlackedOut) return YES;
    CGError err = [self setDisplay:_builtInID enabled:YES];
    if (err != kCGErrorSuccess) {
        NSLog(@"blackoutd: re-enable failed: %d", err);
        return NO;
    }
    _isBlackedOut = NO;
    [_delegate displayController:self blackoutStateChanged:NO];
    return YES;
}

- (BOOL)hasActiveExternalDisplay {
    CGDirectDisplayID displays[8];
    uint32_t count = 0;
    CGGetOnlineDisplayList(8, displays, &count);
    for (uint32_t i = 0; i < count; i++) {
        if (!CGDisplayIsBuiltin(displays[i]) && CGDisplayIsActive(displays[i]))
            return YES;
    }
    return NO;
}

- (BOOL)builtInIsOnline {
    CGDirectDisplayID displays[8];
    uint32_t count = 0;
    CGGetOnlineDisplayList(8, displays, &count);
    for (uint32_t i = 0; i < count; i++) {
        if (CGDisplayIsBuiltin(displays[i])) return YES;
    }
    return NO;
}

- (void)adoptBlackedOutState {
    _isBlackedOut = YES;
}

// MARK: - Private

- (CGDirectDisplayID)discoverBuiltInID {
    CGDirectDisplayID displays[8];
    uint32_t count = 0;
    CGGetOnlineDisplayList(8, displays, &count);
    for (uint32_t i = 0; i < count; i++) {
        if (CGDisplayIsBuiltin(displays[i])) return displays[i];
    }
    return 1; // built-in is always ID 1 on Apple Silicon
}

- (CGError)setDisplay:(CGDirectDisplayID)display enabled:(BOOL)enabled {
    CGDisplayConfigRef config;
    CGError err = CGBeginDisplayConfiguration(&config);
    if (err != kCGErrorSuccess) return err;
    err = CGSConfigureDisplayEnabled(config, display, enabled);
    if (err != kCGErrorSuccess) {
        CGCancelDisplayConfiguration(config);
        return err;
    }
    return CGCompleteDisplayConfiguration(config, kCGConfigurePermanently);
}

- (void)handleReconfiguration:(CGDirectDisplayID)displayID
                         flags:(CGDisplayChangeSummaryFlags)flags {
    if (flags & kCGDisplayBeginConfigurationFlag) return;
    if (_applyingChange) return;

    const CGDisplayChangeSummaryFlags topology =
        kCGDisplayAddFlag | kCGDisplayRemoveFlag |
        kCGDisplayEnabledFlag | kCGDisplayDisabledFlag;
    if (!(flags & topology)) return;

    BOOL hasExternal = [self hasActiveExternalDisplay];

    if (hasExternal && _autoBlackoutOnExternalConnect && !_isBlackedOut) {
        NSLog(@"blackoutd: external connected — blacking out built-in");
        _applyingChange = YES;
        [self enableBlackout];
        _applyingChange = NO;
    } else if (!hasExternal && _isBlackedOut) {
        NSLog(@"blackoutd: no external display — restoring built-in");
        _applyingChange = YES;
        [self disableBlackout];
        _applyingChange = NO;
    }
}

@end
