#!/bin/sh
# Builds blackoutd from source, signs it ad-hoc, and installs the LaunchAgent.

set -e

INSTALL_BIN=/usr/local/bin/blackoutd
AGENT_DIR=$HOME/Library/LaunchAgents
AGENT_PLIST=local.blackoutd.plist
AGENT_DST=$AGENT_DIR/$AGENT_PLIST

cd "$(dirname "$0")"

echo "==> Building blackoutd..."
clang -fobjc-arc \
    -Wall -Wextra \
    -framework Cocoa \
    -framework CoreGraphics \
    -sectcreate __TEXT __info_plist Info.plist \
    -o blackoutd \
    main.m AppDelegate.m DisplayController.m

echo "==> Signing (ad-hoc)..."
codesign --sign - --force blackoutd

echo "==> Installing binary to $INSTALL_BIN (requires sudo)..."
sudo install -d /usr/local/bin
sudo install -m 755 blackoutd "$INSTALL_BIN"

echo "==> Installing LaunchAgent..."
install -d "$AGENT_DIR"
install -m 644 "$AGENT_PLIST" "$AGENT_DST"

echo "==> Bootstrapping agent..."
launchctl bootout "gui/$(id -u)/local.blackoutd" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$AGENT_DST"

echo "==> Done. Use 'blackoutd status' to verify."
