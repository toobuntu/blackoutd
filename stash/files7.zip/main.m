#import <Cocoa/Cocoa.h>
#import <CoreGraphics/CoreGraphics.h>
#import "AppDelegate.h"

static NSString * const kPidFilePath    = @"/tmp/blackoutd.pid";
static NSString * const kSuiteName      = @"local.blackoutd.prefs";
static NSString * const kAutoBlackoutKey = @"autoBlackoutOnExternalConnect";
static NSString * const kAgentLabel     = @"local.blackoutd";

static pid_t readDaemonPid(void) {
    NSString *s = [NSString stringWithContentsOfFile:kPidFilePath
                                            encoding:NSUTF8StringEncoding
                                               error:nil];
    return s ? (pid_t)s.intValue : 0;
}

static int sendSignalToDaemon(int sig) {
    pid_t pid = readDaemonPid();
    if (pid <= 0 || kill(pid, 0) != 0) {
        fprintf(stderr, "blackoutd: daemon not running\n");
        return 1;
    }
    if (kill(pid, sig) != 0) {
        perror("blackoutd: kill");
        return 1;
    }
    return 0;
}

static BOOL builtInIsOnline(void) {
    CGDirectDisplayID displays[8];
    uint32_t count = 0;
    CGGetOnlineDisplayList(8, displays, &count);
    for (uint32_t i = 0; i < count; i++) {
        if (CGDisplayIsBuiltin(displays[i])) return YES;
    }
    return NO;
}

static int printStatus(void) {
    pid_t pid = readDaemonPid();
    if (pid <= 0 || kill(pid, 0) != 0) {
        printf("blackoutd: not running\n");
        return 1;
    }
    NSUserDefaults *defaults = [[NSUserDefaults alloc] initWithSuiteName:kSuiteName];
    BOOL autoMode = [defaults objectForKey:kAutoBlackoutKey] != nil
                        ? [defaults boolForKey:kAutoBlackoutKey]
                        : YES;
    printf("blackoutd: running (pid %d)\n", pid);
    printf("  built-in display : %s\n", builtInIsOnline() ? "active" : "blacked out");
    printf("  auto-blackout    : %s\n", autoMode ? "enabled" : "disabled");
    return 0;
}

static int setAutoBlackout(const char *value) {
    if (strcmp(value, "on") != 0 && strcmp(value, "off") != 0) {
        fprintf(stderr, "Usage: blackoutd auto [on|off]\n");
        return 1;
    }
    BOOL enable = strcmp(value, "on") == 0;
    NSUserDefaults *defaults = [[NSUserDefaults alloc] initWithSuiteName:kSuiteName];
    [defaults setBool:enable forKey:kAutoBlackoutKey];
    [defaults synchronize];
    printf("auto-blackout: %s\n", enable ? "enabled" : "disabled");
    return sendSignalToDaemon(SIGHUP);
}

// Bootout removes the agent so KeepAlive does not restart it.
// The resulting SIGTERM causes applicationWillTerminate to re-enable the display.
static int bootout(void) {
    NSString *domain = [NSString stringWithFormat:@"gui/%d/%@",
                        getuid(), kAgentLabel];
    NSTask *task = [[NSTask alloc] init];
    task.executableURL = [NSURL fileURLWithPath:@"/bin/launchctl"];
    task.arguments = @[@"bootout", domain];
    NSError *err = nil;
    if (![task launchAndReturnError:&err]) {
        fprintf(stderr, "blackoutd: bootout failed: %s\n",
                err.localizedDescription.UTF8String);
        return 1;
    }
    [task waitUntilExit];
    return (int)task.terminationStatus;
}

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        if (argc >= 2) {
            const char *cmd = argv[1];
            if (strcmp(cmd, "on") == 0)     return sendSignalToDaemon(SIGUSR1);
            if (strcmp(cmd, "off") == 0)    return sendSignalToDaemon(SIGUSR2);
            if (strcmp(cmd, "status") == 0) return printStatus();
            if (strcmp(cmd, "quit") == 0)   return bootout();
            if (strcmp(cmd, "auto") == 0) {
                if (argc < 3) {
                    fprintf(stderr, "Usage: blackoutd auto [on|off]\n");
                    return 1;
                }
                return setAutoBlackout(argv[2]);
            }
            if (strcmp(cmd, "start") != 0) {
                fprintf(stderr,
                    "Usage: blackoutd [on|off|status|auto on|off|quit|start]\n");
                return 1;
            }
        }
    }

    NSApplication *app = [NSApplication sharedApplication];
    AppDelegate *delegate = [[AppDelegate alloc] init];
    app.delegate = delegate;
    [app run];
    return 0;
}
