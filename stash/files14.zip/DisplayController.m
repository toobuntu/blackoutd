#import "DisplayController.h"

extern CGError CGSConfigureDisplayEnabled(CGDisplayConfigRef, CGDirectDisplayID, bool);

static void displayReconfigCallback(CGDirectDisplayID displayID,
                                    CGDisplayChangeSummaryFlags flags,
                                    void *userInfo) {
    DisplayController *controller = (__bridge DisplayController *)userInfo;
    [controller handleReconfiguration:displayID flags:flags];
}

@implementation DisplayController {
    CGDirectDisplayID _builtInID;
    BOOL _isBlackedOut;
    BOOL _applyingChange;
}

- (instancetype)init {
    if (!(self = [super init])) return nil;
    _builtInID = [self discoverBuiltInID];
    _autoBlackoutOnExternalConnect = YES;
    CGDisplayRegisterReconfigurationCallback(displayReconfigCallback,
                                             (__bridge void *)self);
    return self;
}

- (void)dealloc {
    CGDisplayRemoveReconfigurationCallback(displayReconfigCallback,
                                           (__bridge void *)self);
}

- (BOOL)isBlackedOut { return _isBlackedOut; }

// MARK: - Public

- (BOOL)enableBlackout {
    if (_isBlackedOut) return YES;
    if (![self hasActiveExternalDisplay]) {
        NSLog(@"blackoutd: refusing blackout — no active external display");
        return NO;
    }
    [self applyEnable:NO];
    return _isBlackedOut;
}

- (BOOL)disableBlackout {
    if (!_isBlackedOut) return YES;
    [self applyEnable:YES];
    return !_isBlackedOut;
}

- (BOOL)hasActiveExternalDisplay {
    return [self hasActiveExternalDisplayExcluding:kCGNullDirectDisplay];
}

// During a removal callback the departing display is still in the online list.
// Pass its ID to exclude it from the external check.
- (BOOL)hasActiveExternalDisplayExcluding:(CGDirectDisplayID)excluded {
    CGDirectDisplayID displays[8];
    uint32_t count = 0;
    CGGetOnlineDisplayList(8, displays, &count);
    for (uint32_t i = 0; i < count; i++) {
        if (displays[i] == excluded) continue;
        if (!CGDisplayIsBuiltin(displays[i]) && CGDisplayIsActive(displays[i]))
            return YES;
    }
    return NO;
}

- (BOOL)builtInIsOnline {
    CGDirectDisplayID displays[8];
    uint32_t count = 0;
    CGGetOnlineDisplayList(8, displays, &count);
    for (uint32_t i = 0; i < count; i++) {
        if (CGDisplayIsBuiltin(displays[i])) return YES;
    }
    return NO;
}

- (void)adoptBlackedOutState {
    _isBlackedOut = YES;
}

// MARK: - Private

- (void)applyEnable:(BOOL)enable {
    NSLog(@"blackoutd: applyEnable:%d builtInID=%u", enable, _builtInID);
    _applyingChange = YES;
    CGError err = [self setDisplay:_builtInID enabled:enable];
    if (err != kCGErrorSuccess) {
        NSLog(@"blackoutd: %s failed err=%d", enable ? "re-enable" : "disable", err);
        _applyingChange = NO;
        return;
    }
    _isBlackedOut = !enable;
    NSLog(@"blackoutd: applyEnable:%d succeeded — isBlackedOut=%d", enable, _isBlackedOut);
    [_delegate displayController:self blackoutStateChanged:_isBlackedOut];
    dispatch_after(
        dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(),
        ^{ self->_applyingChange = NO; });
}

- (CGDirectDisplayID)discoverBuiltInID {
    CGDirectDisplayID displays[8];
    uint32_t count = 0;
    CGGetOnlineDisplayList(8, displays, &count);
    for (uint32_t i = 0; i < count; i++) {
        if (CGDisplayIsBuiltin(displays[i])) return displays[i];
    }
    return 1;
}

- (CGError)setDisplay:(CGDirectDisplayID)display enabled:(BOOL)enabled {
    CGDisplayConfigRef config;
    CGError err = CGBeginDisplayConfiguration(&config);
    if (err != kCGErrorSuccess) return err;
    err = CGSConfigureDisplayEnabled(config, display, enabled);
    if (err != kCGErrorSuccess) {
        CGCancelDisplayConfiguration(config);
        return err;
    }
    return CGCompleteDisplayConfiguration(config, kCGConfigurePermanently);
}

- (void)handleReconfiguration:(CGDirectDisplayID)displayID
                         flags:(CGDisplayChangeSummaryFlags)flags {
    if (flags & kCGDisplayBeginConfigurationFlag) return;

    NSLog(@"blackoutd: reconfig displayID=%u flags=0x%x isBlackedOut=%d applyingChange=%d",
          displayID, flags, _isBlackedOut, _applyingChange);

    const CGDisplayChangeSummaryFlags topology =
        kCGDisplayAddFlag | kCGDisplayRemoveFlag |
        kCGDisplayEnabledFlag | kCGDisplayDisabledFlag;
    if (!(flags & topology)) {
        NSLog(@"blackoutd: reconfig — no topology change, skipping");
        return;
    }

    BOOL isRemoval = (flags & kCGDisplayRemoveFlag) && !CGDisplayIsBuiltin(displayID);

    // For removal events, exclude the departing display from the external check —
    // it is still in the online list at callback time.
    BOOL hasExternal = isRemoval
        ? [self hasActiveExternalDisplayExcluding:displayID]
        : [self hasActiveExternalDisplay];
    NSLog(@"blackoutd: hasExternal=%d isRemoval=%d", hasExternal, isRemoval);

    // Restoring the built-in when the last external display disconnects is a
    // safety invariant — unconditional, even during _applyingChange.
    if (!hasExternal && _isBlackedOut) {
        NSLog(@"blackoutd: no external display — restoring built-in");
        [self applyEnable:YES];
        return;
    }

    // Auto-blackout on connect is suppressed while we are mid-transition to
    // avoid re-entrancy from the topology change our own CGS call triggered.
    if (_applyingChange) {
        NSLog(@"blackoutd: reconfig suppressed — applyingChange");
        return;
    }

    if (hasExternal && _autoBlackoutOnExternalConnect && !_isBlackedOut) {
        NSLog(@"blackoutd: external connected — blacking out built-in");
        [self applyEnable:NO];
    }
}

@end
