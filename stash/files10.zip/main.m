#import <Cocoa/Cocoa.h>
#import <CoreGraphics/CoreGraphics.h>
#import "AppDelegate.h"

static NSString * const kSuiteName       = @"local.blackoutd.prefs";
static NSString * const kAutoBlackoutKey = @"autoBlackoutOnExternalConnect";
static NSString * const kAgentLabel      = @"local.blackoutd";

static NSString *agentPlistPath(void) {
    return [NSHomeDirectory()
        stringByAppendingPathComponent:
            @"Library/LaunchAgents/local.blackoutd.plist"];
}

static NSString *agentDomain(void) {
    return [NSString stringWithFormat:@"gui/%d", getuid()];
}

static NSString *agentService(void) {
    return [NSString stringWithFormat:@"gui/%d/%@", getuid(), kAgentLabel];
}

static int runLaunchctl(NSArray<NSString *> *args) {
    NSTask *task = [[NSTask alloc] init];
    task.executableURL = [NSURL fileURLWithPath:@"/bin/launchctl"];
    task.arguments = args;
    NSError *err = nil;
    if (![task launchAndReturnError:&err]) {
        fprintf(stderr, "blackoutd: launchctl failed: %s\n",
                err.localizedDescription.UTF8String);
        return 1;
    }
    [task waitUntilExit];
    return (int)task.terminationStatus;
}

static BOOL daemonIsRunning(void) {
    // Query launchctl directly — no PID file required.
    NSTask *task = [[NSTask alloc] init];
    task.executableURL = [NSURL fileURLWithPath:@"/bin/launchctl"];
    task.arguments = @[@"print", agentService()];
    task.standardOutput = [NSPipe pipe];
    task.standardError  = [NSPipe pipe];
    NSError *err = nil;
    if (![task launchAndReturnError:&err]) return NO;
    [task waitUntilExit];
    return task.terminationStatus == 0;
}

static pid_t daemonPid(void) {
    NSTask *task = [[NSTask alloc] init];
    task.executableURL = [NSURL fileURLWithPath:@"/bin/launchctl"];
    task.arguments = @[@"print", agentService()];
    NSPipe *pipe = [NSPipe pipe];
    task.standardOutput = pipe;
    task.standardError  = [NSPipe pipe];
    NSError *err = nil;
    if (![task launchAndReturnError:&err]) return 0;
    NSData *data = [pipe.fileHandleForReading readDataToEndOfFile];
    [task waitUntilExit];
    if (task.terminationStatus != 0) return 0;
    NSString *output = [[NSString alloc] initWithData:data
                                             encoding:NSUTF8StringEncoding];
    NSRegularExpression *re = [NSRegularExpression
        regularExpressionWithPattern:@"\\bpid = (\\d+)"
                             options:0 error:nil];
    NSTextCheckingResult *match =
        [re firstMatchInString:output options:0
                         range:NSMakeRange(0, output.length)];
    if (!match) return 0;
    return (pid_t)[[output substringWithRange:[match rangeAtIndex:1]] intValue];
}

static int sendSignalToDaemon(int sig) {
    pid_t pid = daemonPid();
    if (pid <= 0) {
        fprintf(stderr, "blackoutd: daemon not running\n");
        return 1;
    }
    if (kill(pid, sig) != 0) {
        perror("blackoutd: kill");
        return 1;
    }
    return 0;
}

static BOOL builtInIsOnline(void) {
    CGDirectDisplayID displays[8];
    uint32_t count = 0;
    CGGetOnlineDisplayList(8, displays, &count);
    for (uint32_t i = 0; i < count; i++) {
        if (CGDisplayIsBuiltin(displays[i])) return YES;
    }
    return NO;
}

static int printStatus(void) {
    if (!daemonIsRunning()) {
        printf("blackoutd: not running\n");
        return 1;
    }
    pid_t pid = daemonPid();
    NSUserDefaults *defaults = [[NSUserDefaults alloc] initWithSuiteName:kSuiteName];
    BOOL autoMode = [defaults objectForKey:kAutoBlackoutKey] != nil
                        ? [defaults boolForKey:kAutoBlackoutKey]
                        : YES;
    printf("blackoutd: running (pid %d)\n", pid);
    printf("  built-in display : %s\n", builtInIsOnline() ? "active" : "blacked out");
    printf("  auto-blackout    : %s\n", autoMode ? "enabled" : "disabled");
    return 0;
}

static int setAutoBlackout(const char *value) {
    if (strcmp(value, "on") != 0 && strcmp(value, "off") != 0) {
        fprintf(stderr, "Usage: blackoutd auto [on|off]\n");
        return 1;
    }
    BOOL enable = strcmp(value, "on") == 0;
    NSUserDefaults *defaults = [[NSUserDefaults alloc] initWithSuiteName:kSuiteName];
    [defaults setBool:enable forKey:kAutoBlackoutKey];
    [defaults synchronize];
    printf("auto-blackout: %s\n", enable ? "enabled" : "disabled");
    return sendSignalToDaemon(SIGHUP);
}

static int bootout(void) {
    return runLaunchctl(@[@"bootout", agentService()]);
}

static int bootstrap(void) {
    if (daemonIsRunning()) {
        fprintf(stderr, "blackoutd: already running\n");
        return 1;
    }
    NSString *plist = agentPlistPath();
    if (![NSFileManager.defaultManager fileExistsAtPath:plist]) {
        fprintf(stderr, "blackoutd: agent plist not found: %s\n", plist.UTF8String);
        fprintf(stderr, "  Run 'make install' or './install.sh' first.\n");
        return 1;
    }
    int rc = runLaunchctl(@[@"bootstrap", agentDomain(), plist]);
    if (rc == 0) printf("blackoutd: started\n");
    return rc;
}

static void printUsage(void) {
    fprintf(stderr,
        "Usage: blackoutd <command>\n"
        "\n"
        "Commands:\n"
        "  on              Black out built-in display\n"
        "  off             Restore built-in display\n"
        "  status          Show daemon and display status\n"
        "  auto on|off     Enable or disable auto-blackout on external connect\n"
        "  start           Start the daemon via launchctl\n"
        "  quit            Stop the daemon and restore built-in display\n"
        "  daemon          Run as daemon (used by launchd — not for direct use)\n"
    );
}

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        if (argc < 2) {
            printUsage();
            return 1;
        }

        const char *cmd = argv[1];
        if (strcmp(cmd, "on") == 0)      return sendSignalToDaemon(SIGUSR1);
        if (strcmp(cmd, "off") == 0)     return sendSignalToDaemon(SIGUSR2);
        if (strcmp(cmd, "status") == 0)  return printStatus();
        if (strcmp(cmd, "quit") == 0)    return bootout();
        if (strcmp(cmd, "start") == 0)   return bootstrap();
        if (strcmp(cmd, "auto") == 0) {
            if (argc < 3) {
                fprintf(stderr, "Usage: blackoutd auto [on|off]\n");
                return 1;
            }
            return setAutoBlackout(argv[2]);
        }
        if (strcmp(cmd, "daemon") == 0) {
            // Fall through to daemon mode below.
        } else {
            printUsage();
            return 1;
        }
    }

    NSApplication *app = [NSApplication sharedApplication];
    AppDelegate *delegate = [[AppDelegate alloc] init];
    app.delegate = delegate;
    [app run];
    return 0;
}
