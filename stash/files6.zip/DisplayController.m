#import "DisplayController.h"

extern CGError CGSConfigureDisplayEnabled(CGDisplayConfigRef, CGDirectDisplayID, bool);

static void displayReconfigCallback(CGDirectDisplayID displayID,
                                    CGDisplayChangeSummaryFlags flags,
                                    void *userInfo) {
    DisplayController *controller = (__bridge DisplayController *)userInfo;
    [controller handleReconfiguration:displayID flags:flags];
}

@implementation DisplayController {
    CGDirectDisplayID _builtInID;
    BOOL _isBlackedOut;
    BOOL _applyingChange;
}

- (instancetype)init {
    if (!(self = [super init])) return nil;
    _builtInID = [self discoverBuiltInID];
    _autoBlackoutOnExternalConnect = YES;
    CGDisplayRegisterReconfigurationCallback(displayReconfigCallback,
                                             (__bridge void *)self);
    return self;
}

- (void)dealloc {
    CGDisplayRemoveReconfigurationCallback(displayReconfigCallback,
                                           (__bridge void *)self);
}

- (BOOL)isBlackedOut { return _isBlackedOut; }

// MARK: - Public

- (BOOL)enableBlackout {
    if (_isBlackedOut) return YES;
    if (![self hasActiveExternalDisplay]) {
        NSLog(@"blackoutd: refusing blackout — no active external display");
        return NO;
    }
    [self applyEnable:NO];
    return _isBlackedOut;
}

- (BOOL)disableBlackout {
    if (!_isBlackedOut) return YES;
    [self applyEnable:YES];
    return !_isBlackedOut;
}

- (BOOL)hasActiveExternalDisplay {
    CGDirectDisplayID displays[8];
    uint32_t count = 0;
    CGGetOnlineDisplayList(8, displays, &count);
    for (uint32_t i = 0; i < count; i++) {
        if (!CGDisplayIsBuiltin(displays[i]) && CGDisplayIsActive(displays[i]))
            return YES;
    }
    return NO;
}

- (BOOL)builtInIsOnline {
    CGDirectDisplayID displays[8];
    uint32_t count = 0;
    CGGetOnlineDisplayList(8, displays, &count);
    for (uint32_t i = 0; i < count; i++) {
        if (CGDisplayIsBuiltin(displays[i])) return YES;
    }
    return NO;
}

- (void)adoptBlackedOutState {
    _isBlackedOut = YES;
}

// MARK: - Private

// All CGS enable/disable calls go through here so _applyingChange is
// always set before the call and cleared after the callback storm settles.
- (void)applyEnable:(BOOL)enable {
    _applyingChange = YES;
    CGError err = [self setDisplay:_builtInID enabled:enable];
    if (err != kCGErrorSuccess) {
        NSLog(@"blackoutd: %s failed: %d", enable ? "re-enable" : "disable", err);
        _applyingChange = NO;
        return;
    }
    _isBlackedOut = !enable;
    [_delegate displayController:self blackoutStateChanged:_isBlackedOut];
    // Hold the guard until WindowServer has finished its reconfiguration
    // callback cycle (~500ms is typical; 2s provides a safe margin).
    dispatch_after(
        dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(),
        ^{ self->_applyingChange = NO; });
}

- (CGDirectDisplayID)discoverBuiltInID {
    CGDirectDisplayID displays[8];
    uint32_t count = 0;
    CGGetOnlineDisplayList(8, displays, &count);
    for (uint32_t i = 0; i < count; i++) {
        if (CGDisplayIsBuiltin(displays[i])) return displays[i];
    }
    return 1;
}

- (CGError)setDisplay:(CGDirectDisplayID)display enabled:(BOOL)enabled {
    CGDisplayConfigRef config;
    CGError err = CGBeginDisplayConfiguration(&config);
    if (err != kCGErrorSuccess) return err;
    err = CGSConfigureDisplayEnabled(config, display, enabled);
    if (err != kCGErrorSuccess) {
        CGCancelDisplayConfiguration(config);
        return err;
    }
    return CGCompleteDisplayConfiguration(config, kCGConfigurePermanently);
}

- (void)handleReconfiguration:(CGDirectDisplayID)displayID
                         flags:(CGDisplayChangeSummaryFlags)flags {
    if (flags & kCGDisplayBeginConfigurationFlag) return;
    if (_applyingChange) return;

    const CGDisplayChangeSummaryFlags topology =
        kCGDisplayAddFlag | kCGDisplayRemoveFlag |
        kCGDisplayEnabledFlag | kCGDisplayDisabledFlag;
    if (!(flags & topology)) return;

    BOOL hasExternal = [self hasActiveExternalDisplay];

    if (hasExternal && _autoBlackoutOnExternalConnect && !_isBlackedOut) {
        NSLog(@"blackoutd: external connected — blacking out built-in");
        [self applyEnable:NO];
    } else if (!hasExternal && _isBlackedOut) {
        NSLog(@"blackoutd: no external display — restoring built-in");
        [self applyEnable:YES];
    }
}

@end
