# blackoutd

A macOS menu bar daemon that blacks out the built-in display when an external
display is connected, preserving screen real estate and reducing distraction.

## Requirements

**Runtime:**
- macOS 13 or later
- Apple Silicon Mac (tested on M2 MacBook Air)

**Build:**
- Xcode Command Line Tools: `xcode-select --install`

## Installation

```sh
make
sudo make install
```

This builds the binary, installs it to `/usr/local/bin/blackoutd`, installs the
LaunchAgent plist, and bootstraps the agent for the current user.

## Usage

```
blackoutd on                  Black out built-in display
blackoutd off                 Restore built-in display
blackoutd status              Show daemon and display status
blackoutd auto on|off         Enable/disable auto-blackout on external connect
blackoutd daemon start        Start daemon via launchctl
blackoutd daemon stop         Stop daemon and restore built-in display
```

## Upgrade

```sh
make clean; make; make reinstall
```

## Uninstall

```sh
make uninstall
```

## Logging

blackoutd writes structured logs to stderr, captured to
`~/Library/Logs/blackoutd.log` via the LaunchAgent plist. Console.app will
find the log automatically under the Logs category. Log lines are tagged by
subsystem:

```
[startup]   session init and state restoration
[change]    display connectivity events; includes class=hardware|virtual|builtin
[external]  external display evaluation result (vendor, hardware vs. virtual)
[builtin]   built-in display actions and outcomes
[state]     decision logic and conclusions
[sleep]     sleep transition — display changes ignored until wake
[wake]      wake transition — display change monitoring resumed
```

Example sequence for external display connect:

```
[change] id=2 event=connected class=hardware
[external] id=2 vendor=0x10ac (Dell) — hardware display detected
[state] hasExternal=1 autoBlackout=1 isBlackedOut=0 — initiating blackout action
[builtin] id=1 action=blackout result=pending isBlackedOut=0
[builtin] id=1 action=blackout result=complete isBlackedOut=1
[builtin] id=1 action=blackout result=settled isBlackedOut=1
```

Example sequence for sleep/wake with external display remaining connected:

```
[sleep] — ignoring display changes
[change] id=N event=connected class=virtual — ignored, sleeping
[wake] — resuming display change monitoring
[change] id=N event=connected class=hardware
[external] id=2 vendor=0x10ac (Dell) — hardware display detected
[state] hasExternal=1 autoBlackout=1 isBlackedOut=0 — initiating blackout action
[builtin] id=1 action=blackout result=pending isBlackedOut=0
[builtin] id=1 action=blackout result=complete isBlackedOut=1
[builtin] id=1 action=blackout result=settled isBlackedOut=1
```

Verbosity is level 1 by default (semantic logs only). Level 2 adds
`[verbose=2]`-tagged lines with raw CGDisplayChangeSummaryFlags values and
decoded connectivity details, useful for diagnosing unexpected display events.

Enable verbose logging at runtime without restarting the daemon:

```sh
defaults write blackoutd verbosityLevel -int 2
```

Reset to default:

```sh
defaults delete blackoutd verbosityLevel
```

## Motivation

blackoutd exists for MacBook users who work primarily on an external display but
use the built-in keyboard and trackpad. macOS mirrors or extends the desktop to
the built-in display whenever it is active — which wastes energy and, more
practically, means the built-in screen is visible to others nearby during video
calls even when you are looking at the external.

The tool was built specifically to suppress that. The built-in is fully disabled
at the compositor level when an external is connected, and automatically restored
when the external is disconnected, so the Mac is never left without a usable
display.

## Why not pmset?

`pmset displaysleepnow` turns off all displays immediately but wakes them on any
input and does not persist across sleep/wake. `pmset sleepnow` puts the whole
system to sleep.

Neither does what blackoutd does: keep the external display live and active while
suppressing only the built-in, persistently, with automatic re-application after
sleep/wake cycles and display reconnects.

Clamshell mode (lid closed) achieves a similar result but requires a power
connection and an external keyboard and mouse. blackoutd is designed for the
opposite situation — lid open, using the built-in keyboard and trackpad, external
display only.

## How it works

blackoutd uses the private `CGSConfigureDisplayEnabled` symbol (re-exported from
SkyLight.framework through CoreGraphics) to disable the built-in display at the
compositor level. The display is fully off — not just dimmed — while the daemon
process holds a live WindowServer connection that maintains the enabled state.

On external display disconnect, the built-in is unconditionally restored
regardless of user intent. Leaving a Mac with no usable display is never
acceptable.

## Known issues

**Username change**: The LaunchAgent plist and log path are hardcoded to the
home directory at install time. If the macOS username is changed after
installation, run `make reinstall` from the source directory to regenerate
the plist and re-register the agent with the correct paths.

**Preferences migration**: Versions prior to the `blackoutd` suite name change
stored preferences under `local.blackoutd.prefs`. That file is no longer read.
All settings default to safe values on first run (`autoBlackoutOnExternalConnect`
defaults to enabled). The old file can be removed:

```sh
defaults delete local.blackoutd.prefs
```

**SIGKILL**: If the daemon is killed with `SIGKILL` while the built-in is blacked
out, the display cannot be restored programmatically until the WindowServer
re-enumerates displays. Disconnect and reconnect the external display, or log out
and back in. Use `blackoutd daemon stop` or the menu bar Quit option instead of
`kill -9`.

**Coexistence with BetterDisplay/Lunar**: If another display manager is running
with its own disconnect-on-external feature enabled, the two daemons will fight.
Disable that feature in the other app before using blackoutd.

## Tech notes

### SMAppService (future)
If blackoutd is ever packaged as `Blackout.app`, the `launchctl bootstrap/bootout`
subprocess calls in `main.m` should be replaced with
`[SMAppService mainAppService]` register/unregister. This requires the LaunchAgent
plist to live at `Blackout.app/Contents/Library/LaunchAgents/local.blackoutd.plist`
and the binary to run from inside the bundle. See `man SMAppService` and
[Apple Developer docs](https://developer.apple.com/documentation/servicemanagement/smappservice).

### Mach port presence detection (planned)
`blackoutd status` previously used `launchctl print` to detect whether the
daemon was running, whose output is explicitly documented as unstable
(`man launchctl`: "This output is NOT API"). This has been replaced with
`launchctl list` (stable legacy format, tab-separated PID/Status/Label
columns) filtered for the agent label. The planned longer-term replacement
is a named Mach port (`com.github.toobuntu.blackoutd`) registered on daemon
startup. The CLI checks for port existence via `bootstrap_look_up()` —
stable, synchronous, no subprocess.

### Display ID stability
`CGDirectDisplayID` values can change across reboots. The built-in display on
Apple Silicon is reliably ID 1 in practice, but `discoverBuiltInID` uses
`CGDisplayIsBuiltin()` enumeration for correctness.

## License

MIT
